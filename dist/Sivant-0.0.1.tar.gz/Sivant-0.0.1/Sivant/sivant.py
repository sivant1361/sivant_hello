def hello():
    print("Guten Tag! It's me Sivant :)")