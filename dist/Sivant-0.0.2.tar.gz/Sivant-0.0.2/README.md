It is a demo package created for learning purpose.

It contains a function named "hello" to display a message